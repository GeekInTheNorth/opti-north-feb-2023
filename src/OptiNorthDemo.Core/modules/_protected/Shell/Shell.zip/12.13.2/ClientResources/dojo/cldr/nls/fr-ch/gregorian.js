//>>built
define("dojo/cldr/nls/fr-ch/gregorian",{"timeFormat-full":"HH.mm:ss 'h' zzzz","dateFormat-full":"EEEE, d MMMM y","dateFormat-short":"dd.MM.yy"});